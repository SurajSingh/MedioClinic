SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_Customer](
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerFirstName] [nvarchar](200) NOT NULL,
	[CustomerLastName] [nvarchar](200) NOT NULL,
	[CustomerEmail] [nvarchar](254) NULL,
	[CustomerPhone] [nvarchar](26) NULL,
	[CustomerFax] [nvarchar](50) NULL,
	[CustomerCompany] [nvarchar](200) NULL,
	[CustomerUserID] [int] NULL,
	[CustomerGUID] [uniqueidentifier] NOT NULL,
	[CustomerTaxRegistrationID] [nvarchar](50) NULL,
	[CustomerOrganizationID] [nvarchar](50) NULL,
	[CustomerLastModified] [datetime2](7) NOT NULL,
	[CustomerSiteID] [int] NULL,
	[CustomerCreated] [datetime2](7) NULL,
 CONSTRAINT [PK_COM_Customer] PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerCompany] ON [dbo].[COM_Customer]
(
	[CustomerCompany] ASC
)
WHERE ([CustomerCompany] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerEmail] ON [dbo].[COM_Customer]
(
	[CustomerEmail] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerFirstName] ON [dbo].[COM_Customer]
(
	[CustomerFirstName] ASC
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerLastName] ON [dbo].[COM_Customer]
(
	[CustomerLastName] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerSiteID] ON [dbo].[COM_Customer]
(
	[CustomerSiteID] ASC
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_Customer_CustomerUserID] ON [dbo].[COM_Customer]
(
	[CustomerUserID] ASC
)
GO
ALTER TABLE [dbo].[COM_Customer] ADD  CONSTRAINT [DEFAULT_COM_Customer_CustomerGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [CustomerGUID]
GO
ALTER TABLE [dbo].[COM_Customer]  WITH CHECK ADD  CONSTRAINT [FK_COM_Customer_CustomerSiteID_CMS_Site] FOREIGN KEY([CustomerSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_Customer] CHECK CONSTRAINT [FK_COM_Customer_CustomerSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[COM_Customer]  WITH CHECK ADD  CONSTRAINT [FK_COM_Customer_CustomerUserID_CMS_User] FOREIGN KEY([CustomerUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[COM_Customer] CHECK CONSTRAINT [FK_COM_Customer_CustomerUserID_CMS_User]
GO
