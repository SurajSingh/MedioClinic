SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_CMS_WebFarmServerTasks_Insert]
@FirstGuid uniqueidentifier,
	@Count int,
	@CurrentServerId int
AS
BEGIN
DECLARE @taskId INT;
    SELECT @taskId = [TaskID] FROM [CMS_WebFarmTask] WITH (NOLOCK) WHERE [TaskGUID] = @FirstGuid
    SET @Count = @taskId + @Count

    ;WITH sl (ID, IsDisabled) AS
	(
        SELECT ServerID, CAST(case when ServerLog.LogCode LIKE N'AutoDisabled' then 1 else 0 end as bit) 
		FROM [CMS_WebFarmServer] WITH (NOLOCK) OUTER APPLY (
            SELECT  TOP 1 LogCode
            FROM    [CMS_WebFarmServerLog] WITH (NOLOCK)
            WHERE   [CMS_WebFarmServerLog].ServerID = [CMS_WebFarmServer].ServerID
            ORDER BY LogTime DESC) ServerLog
			WHERE [CMS_WebFarmServer].ServerID <> @CurrentServerId
	)
	INSERT INTO [CMS_WebFarmServerTask] ( [ServerID], [TaskID] )
        SELECT sl.ID, [TaskID] FROM [CMS_WebFarmTask] WITH (NOLOCK), sl
        WHERE [TaskID] >= @taskId AND [TaskID] < @Count AND ([TaskIsMemory] IS NULL OR [TaskIsMemory] = 0 OR sl.IsDisabled = 0) -- Insert server tasks if task is not memory, or server is not auto-disabled
END
GO
